<table width="195" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="195" height="35" background="images/bgn_login2.png"><div align="left" style="color:#fff; font-family:Tahoma; font-size: 14px; padding-left:30px">ĐĂNG NHẬP</div></td>
  </tr>
  <tr>
    <td align="center" background="images/toplist-content.gif" style="border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC; background-repeat:repeat-x"> 
    <form action="include/login-authentication.php" method="post">
    <div align="left" style="padding-top:5px; font-family:Tahoma; font-size:12px; width:190px; padding-left:2px; height:25px">
    User:  <input type="text" name="user" style="width: 130px; background-image:url(images/username.gif); background-position: 2px 2px; background-repeat:no-repeat; padding-left:20px; border:1px solid #999; height:20px" /></div>
    <div align="left" style="padding-top:5px; padding-bottom:5px; font-family:Tahoma; font-size:12px; width:190px; padding-left:2px; height:25px">
    Pass: <input type="password" name="pass" style="width:130px; background-image:url(images/password.gif); background-position: 2px 2px;	background-repeat:no-repeat; padding-left:20px; border:1px solid #999; height:20px" /></div>
    <input type="submit" value="Đăng nhập" class="button" onmouseover="style.background='url(images/button-2-o.gif)'" onmouseout="style.background='url(images/button-o.gif)'" /><br />
    <div style="padding-top:10px; font-family:Tahoma; font-size:12px"> <a href="index.php?b=dk">&raquo; Đăng ký</a> &nbsp; &nbsp;</div>
    </form>
    </td>
  </tr>
</table>
