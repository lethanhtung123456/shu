<table width="195" border="0" cellspacing="0" cellpadding="0" style="border:1px solid #CCCCCC ">
  <tr>
	<td width="195" height="35" background="images/bgn_unlock2.png"><div align="left" style="color:#FFF; font-family:Tahoma; font-size: 14px; padding-left: 30px">THÔNG TIN ĐĂNG NHẬP
	</div></td>
  </tr>
  <tr>
	<td height="35" bgcolor="#F9F9F9">
	<div align="left" style="color:#000; font-family:Tahoma; font-size: 13px; color:#000000; padding-left:5px; font-weight:bold">Tên đăng nhập: <?php echo $_SESSION['user']; ?></div></td>
  </tr>
  <tr>
  	<td height="30" style="padding-left:20px">&raquo; <a href="index.php?b=ttcn">Thông tin cá nhân</a></td>
  </tr>
    <tr>
  	<td height="30" style="padding-left:20px">&raquo;<a href="index.php?b=cpw"> Đổi mật khẩu</a></td>
  </tr>
  <tr>
	<td height="25" style="border-top:1px dotted #CCCCCC"><div align="center"><a href="include/logout.php" style="color:#000; font-family:Tahoma; font-size: 12px; font-weight:bold;">Thoát</a><br />
	</div></td>
  </tr>
</table>          