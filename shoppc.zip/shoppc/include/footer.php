<embed id="Advertisement" 
width="960" height="100" 
flashvars="clickTARGET=_blank&clickTAG=#" 
allowscriptaccess="always"
wmode="transparent" quality="high" 
name="Advertisement" style="admincp" 
src="images/quangcao.swf" 
type="application/x-shockwave-flash">
Website kinh doanh máy tính xách tay trực tuyến</br>
