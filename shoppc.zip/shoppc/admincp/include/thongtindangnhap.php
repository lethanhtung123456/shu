<table width="220" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td style="padding-left:10px; border-bottom:1px solid #CCCCCC; border-top:1px solid #CCCCCC; background-image:url(../../bg.jpg)" height="30"><div align="left" style="color:#FFF; font-family:Tahoma; font-size: 13px; font-weight:bold">THÔNG TIN ĐĂNG NHẬP:</div></td>
          </tr>
          <tr>
            <td style="padding-left:20px" height="60" bgcolor="#F9F9F9">
            <div align="left" style="color:#0B55C4; font-family:Tahoma; font-size: 13px; color:#000000"><img align="absmiddle" src="../../image/arrow.gif">Tên đăng nhập: <?php echo $_SESSION['hoten']; ?></div></td>
          </tr>
          <tr>
          	<td height="25" style="border-bottom:1px solid #CCCCCC; border-top:1px solid #CCC"><div align="center"><a href="/sitemanager/logout.php" style="color:#0B55C4; font-family:Tahoma; font-size: 12px; font-weight:bold;">THOÁT ĐĂNG NHẬP</a><br />
          	</div></td>
          </tr>
        </table>          