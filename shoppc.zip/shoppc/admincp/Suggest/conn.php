<?php
$conn = mysql_connect("localhost","root","root") or die("could not connect to server");
 mysql_select_db("vietducdb",$conn) or die("could not connect to database");
?>
