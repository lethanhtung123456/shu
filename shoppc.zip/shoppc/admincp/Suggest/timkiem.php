<table width="350px" border="0" cellspacing="0" cellpadding="0">
         <form action="/admin/?b=sp-list&act=tk" method="GET" > 
         <input type="hidden" name="b" value="sp-list" />
         <input type="hidden" name="act" value="tk" />
          <tr>
            <td style="border-left: 1px solid #CCCCCC; width:250px">
            <div style="padding-top:5px; padding-bottom:3px; padding-right:5px" align="right">
            <input type="text" name="text_content" id="text_content" class="timkiem-textbox" maxlength="70" style="height:18px; border:1px solid #999; width:165px" onkeyup = "getScriptPage('box','text_content')"  /></div></td>
            <td style="border-right: 1px solid #CCCCCC; width:100px">
            <input type="submit" value="Tìm" class="button" onmouseover="style.background='url(../images/button-2.gif)'" onmouseout="style.background='url(../images/button.gif)'" />
           </td>
          </tr>  
          </form> 
        </table>